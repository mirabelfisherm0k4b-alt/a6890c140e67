// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ubsan\n", stdout);
  return lionss_run_workload("ubsan");
}

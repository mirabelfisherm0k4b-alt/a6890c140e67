// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("hardening check"); }
int main(){
  announce();
  return lionss_run_workload("hardening-check");
}

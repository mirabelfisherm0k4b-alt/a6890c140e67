// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("idempotency tests"); }
int main(){
  announce();
  return lionss_run_workload("idempotency-tests");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux x86 64\n", stdout);
  return lionss_run_workload("linux-x86-64");
}

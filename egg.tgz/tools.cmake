# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(openbsd-build src/openbsd-build.cpp)
set_property(TARGET openbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(openbsd-build lionss pthread)

add_executable(linux-s390x src/linux-s390x.cpp)
set_property(TARGET linux-s390x PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-s390x lionss pthread)

add_executable(cross-android src/cross-android.cpp)
set_property(TARGET cross-android PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-android lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(rollback-tests src/rollback-tests.cpp)
set_property(TARGET rollback-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(rollback-tests lionss pthread)

add_executable(android-armv7 src/android-armv7.cpp)
set_property(TARGET android-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-armv7 lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(cmake-config-export src/cmake-config-export.cpp)
set_property(TARGET cmake-config-export PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-config-export lionss pthread)

add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(throughput-bench src/throughput-bench.cpp)
set_property(TARGET throughput-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(throughput-bench lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(doxygen src/doxygen.cpp)
set_property(TARGET doxygen PROPERTY CXX_STANDARD 11)
target_link_libraries(doxygen lionss pthread)

add_executable(makefiles-build src/makefiles-build.cpp)
set_property(TARGET makefiles-build PROPERTY CXX_STANDARD 11)
target_link_libraries(makefiles-build lionss pthread)

add_executable(modules-build src/modules-build.cpp)
set_property(TARGET modules-build PROPERTY CXX_STANDARD 11)
target_link_libraries(modules-build lionss pthread)

add_executable(big-endian-check src/big-endian-check.cpp)
set_property(TARGET big-endian-check PROPERTY CXX_STANDARD 11)
target_link_libraries(big-endian-check lionss pthread)

add_executable(memory-sanitizer src/memory-sanitizer.cpp)
set_property(TARGET memory-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-sanitizer lionss pthread)

add_executable(lock-bench src/lock-bench.cpp)
set_property(TARGET lock-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(lock-bench lionss pthread)

add_executable(memory-profile src/memory-profile.cpp)
set_property(TARGET memory-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-profile lionss pthread)

add_executable(rdtsc-calibration src/rdtsc-calibration.cpp)
set_property(TARGET rdtsc-calibration PROPERTY CXX_STANDARD 11)
target_link_libraries(rdtsc-calibration lionss pthread)

add_executable(simd-throughput src/simd-throughput.cpp)
set_property(TARGET simd-throughput PROPERTY CXX_STANDARD 11)
target_link_libraries(simd-throughput lionss pthread)

add_executable(werror-build src/werror-build.cpp)
set_property(TARGET werror-build PROPERTY CXX_STANDARD 11)
target_link_libraries(werror-build lionss pthread)

add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(bisect-regression src/bisect-regression.cpp)
set_property(TARGET bisect-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(bisect-regression lionss pthread)

add_executable(ubsan src/ubsan.cpp)
set_property(TARGET ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(ubsan lionss pthread)

add_executable(scoop-manifest src/scoop-manifest.cpp)
set_property(TARGET scoop-manifest PROPERTY CXX_STANDARD 11)
target_link_libraries(scoop-manifest lionss pthread)

add_executable(negative-tests src/negative-tests.cpp)
set_property(TARGET negative-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(negative-tests lionss pthread)

